using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CSharpMaster : System.Web.UI.Page
{
    Panel pnlTextBox;
    Panel pnlDropDownList;
    protected void Page_Load(object sender, EventArgs e)
    {

        //Get ContentPlaceHolder
        ContentPlaceHolder content = (ContentPlaceHolder)this.Master.FindControl("ContentPlaceHolder1");


        Literal lt;
        Label lb;

        //Dynamic TextBox Panel
        pnlTextBox = new Panel();
        pnlTextBox.ID = "pnlTextBox";
        pnlTextBox.BorderWidth = 1;
        pnlTextBox.Width = 300;
        content.Controls.Add(pnlTextBox);
        lt = new Literal();
        lt.Text = "<br />";
        content.Controls.Add(lt);
        lb = new Label();
        lb.Text = "Dynamic TextBox<br />";
        pnlTextBox.Controls.Add(lb);

        //Button To add TextBoxes
        Button btnAddTxt = new Button();
        btnAddTxt.ID = "btnAddTxt";
        btnAddTxt.Text = "Add TextBox";
        btnAddTxt.Click += new System.EventHandler(btnAdd_Click);
        content.Controls.Add(btnAddTxt);


        //Dynamic DropDownList Panel
        pnlDropDownList = new Panel();
        pnlDropDownList.ID = "pnlDropDownList";
        pnlDropDownList.BorderWidth = 1;
        pnlDropDownList.Width = 300;
        content.Controls.Add(pnlDropDownList);
        lt = new Literal();
        lt.Text = "<br />";
        content.Controls.Add(lt);
        lb = new Label();
        lb.Text = "Dynamic DropDownList<br />";
        pnlDropDownList.Controls.Add(lb);

        //Button To add DropDownlist
        Button btnAddDdl = new Button();
        btnAddDdl.ID = "btnAddDdl";
        btnAddDdl.Text = "Add DropDown";
        btnAddDdl.Click += new System.EventHandler(btnAdd_Click);
        content.Controls.Add(btnAddDdl);


        if (IsPostBack)
        {
            RecreateControls("txtDynamic", "TextBox");
            RecreateControls("ddlDynamic", "DropDownList");
        }

        //Dummy Button To do PostBack
        Button btnSubmit = new Button();
        btnSubmit.ID = "btnSubmit";
        btnSubmit.Text = "Submit";
        btnSubmit.Click += new System.EventHandler(btnSubmit_Click);
        content.Controls.Add(btnSubmit);


    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        if (btn.ID == "btnAddTxt")
        {
            int cnt = FindOccurence("txtDynamic");
            TextBox txt = new TextBox();
            txt.ID = "txtDynamic-" + Convert.ToString(cnt + 1);
            pnlTextBox.Controls.Add(txt);

            Literal lt = new Literal();
            lt.Text = "<br />";
            pnlTextBox.Controls.Add(lt);
        }

        if (btn.ID == "btnAddDdl")
        {
            int cnt = FindOccurence("ddlDynamic");
            DropDownList ddl = new DropDownList();
            ddl.ID = "ddlDynamic-" + Convert.ToString(cnt + 1);
            ddl.Items.Add(new ListItem("One", "1"));
            ddl.Items.Add(new ListItem("Two", "2"));
            ddl.Items.Add(new ListItem("Three", "3"));
            pnlDropDownList.Controls.Add(ddl);

            Literal lt = new Literal();
            lt.Text = "<br />";
            pnlDropDownList.Controls.Add(lt);
        }
    }

    private int FindOccurence(string substr)
    {
        string reqstr = Request.Form.ToString();
        return ((reqstr.Length - reqstr.Replace(substr, "").Length) / substr.Length);
    }

    private void RecreateControls(string ctrlPrefix, string ctrlType)
    {
        string[] ctrls = Request.Form.ToString().Split('&');
        int cnt = FindOccurence(ctrlPrefix);
        if (cnt > 0)
        {
            Literal lt;
            for (int k = 1; k <= cnt; k++)
            {
                for (int i = 0; i < ctrls.Length; i++)
                {
                    if (ctrls[i].Contains(ctrlPrefix + "-" + k.ToString()))
                    {
                        string ctrlName = ctrls[i].Split('=')[0];
                        string ctrlValue = ctrls[i].Split('=')[1];

                         //Decode the Value
                        ctrlValue = Server.UrlDecode(ctrlValue);  

                        if (ctrlType == "TextBox")
                        {
                            TextBox txt = new TextBox();
                            txt.ID = ctrlName;
                            txt.Text = ctrlValue;
                            pnlTextBox.Controls.Add(txt);
                            lt = new Literal();
                            lt.Text = "<br />";
                            pnlTextBox.Controls.Add(lt);
                        }

                        if (ctrlType == "DropDownList")
                        {
                            DropDownList ddl = new DropDownList();
                            ddl.ID = ctrlName;

                            //Rebind Data
                            ddl.Items.Add(new ListItem("One", "1"));
                            ddl.Items.Add(new ListItem("Two", "2"));
                            ddl.Items.Add(new ListItem("Three", "3"));

                            //Select the Preselected Item
                            ddl.Items.FindByValue(ctrlValue).Selected = true;
                            pnlDropDownList.Controls.Add(ddl);
                            lt = new Literal();
                            lt.Text = "<br />";
                            pnlDropDownList.Controls.Add(lt);
                        }
                        break;
                    }
                }
            }
        }
    }
}
