
Partial Class Default2
    Inherits System.Web.UI.Page

    Dim pnlTextBox As Panel
    Dim pnlDropDownList As Panel

   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lt As Literal
        Dim lb As Label

        'Dynamic TextBox Panel 
        pnlTextBox = New Panel()
        pnlTextBox.ID = "pnlTextBox"
        pnlTextBox.BorderWidth = 1
        pnlTextBox.Width = 300
        Me.form1.Controls.Add(pnlTextBox)
        lt = New Literal()
        lt.Text = "<br />"
        Me.form1.Controls.Add(lt)
        lb = New Label()
        lb.Text = "Dynamic TextBox<br />"
        pnlTextBox.Controls.Add(lb)

        'Button To add TextBoxes 
        Dim btnAddTxt As New Button()
        btnAddTxt.ID = "btnAddTxt"
        btnAddTxt.Text = "Add TextBox"
        AddHandler btnAddTxt.Click, AddressOf btnAdd_Click
        Me.form1.Controls.Add(btnAddTxt)



        'Dynamic DropDownList Panel 
        pnlDropDownList = New Panel()
        pnlDropDownList.ID = "pnlDropDownList"
        pnlDropDownList.BorderWidth = 1
        pnlDropDownList.Width = 300
        Me.form1.Controls.Add(pnlDropDownList)
        lt = New Literal()
        lt.Text = "<br />"
        Me.form1.Controls.Add(lt)
        lb = New Label()
        lb.Text = "Dynamic DropDownList<br />"
        pnlDropDownList.Controls.Add(lb)

        'Button To add DropDownlist 
        Dim btnAddDdl As New Button()
        btnAddDdl.ID = "btnAddDdl"
        btnAddDdl.Text = "Add DropDown"
        AddHandler btnAddDdl.Click, AddressOf btnAdd_Click
        Me.form1.Controls.Add(btnAddDdl)


        If IsPostBack Then
            RecreateControls("txtDynamic", "TextBox")
            RecreateControls("ddlDynamic", "DropDownList")
        End If

        'Dummy Button To do PostBack 
        Dim btnSubmit As New Button()
        btnSubmit.ID = "btnSubmit"
        btnSubmit.Text = "Submit"
        AddHandler btnSubmit.Click, AddressOf btnSubmit_Click
        Me.form1.Controls.Add(btnSubmit)
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs)
        'OnClick Event Handler for btnSubmit
    End Sub
    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim btn As Button = DirectCast(sender, Button)
        If btn.ID = "btnAddTxt" Then
            Dim cnt As Integer = FindOccurence("txtDynamic")
            Dim txt As New TextBox()
            txt.ID = "txtDynamic-" & Convert.ToString(cnt + 1)
            pnlTextBox.Controls.Add(txt)

            Dim lt As New Literal()
            lt.Text = "<br />"
            pnlTextBox.Controls.Add(lt)
        End If

        If btn.ID = "btnAddDdl" Then
            Dim cnt As Integer = FindOccurence("ddlDynamic")
            Dim ddl As New DropDownList()
            ddl.ID = "ddlDynamic-" & Convert.ToString(cnt + 1)
            ddl.Items.Add(New ListItem("One", "1"))
            ddl.Items.Add(New ListItem("Two", "2"))
            ddl.Items.Add(New ListItem("Three", "3"))
            pnlDropDownList.Controls.Add(ddl)

            Dim lt As New Literal()
            lt.Text = "<br />"
            pnlDropDownList.Controls.Add(lt)
        End If
    End Sub

    Private Function FindOccurence(ByVal substr As String) As Integer
        Dim reqstr As String = Request.Form.ToString()
        Return ((reqstr.Length - reqstr.Replace(substr, "").Length) / substr.Length)
    End Function

    Private Sub RecreateControls(ByVal ctrlPrefix As String, ByVal ctrlType As String)
        Dim ctrls As String() = Request.Form.ToString().Split("&"c)
        Dim cnt As Integer = FindOccurence(ctrlPrefix)
        If cnt > 0 Then
            Dim lt As Literal
            For k As Integer = 1 To cnt
                For i As Integer = 0 To ctrls.Length - 1
                    If ctrls(i).Contains((ctrlPrefix & "-") + k.ToString()) Then
                        Dim ctrlName As String = ctrls(i).Split("="c)(0)
                        Dim ctrlValue As String = ctrls(i).Split("="c)(1)

                        'Decode the Value
                        ctrlValue = Server.UrlDecode(ctrlValue)


                        If ctrlType = "TextBox" Then
                            Dim txt As New TextBox()
                            txt.ID = ctrlName
                            txt.Text = ctrlValue
                            pnlTextBox.Controls.Add(txt)
                            lt = New Literal()
                            lt.Text = "<br />"
                            pnlTextBox.Controls.Add(lt)
                        End If

                        If ctrlType = "DropDownList" Then
                            Dim ddl As New DropDownList()
                            ddl.ID = ctrlName

                            'Rebind Data 
                            ddl.Items.Add(New ListItem("One", "1"))
                            ddl.Items.Add(New ListItem("Two", "2"))
                            ddl.Items.Add(New ListItem("Three", "3"))

                            'Select the Preselected Item 
                            ddl.Items.FindByValue(ctrlValue).Selected = True
                            pnlDropDownList.Controls.Add(ddl)
                            lt = New Literal()
                            lt.Text = "<br />"
                            pnlDropDownList.Controls.Add(lt)
                        End If
                        Exit For
                    End If
                Next
            Next
        End If
    End Sub
End Class
