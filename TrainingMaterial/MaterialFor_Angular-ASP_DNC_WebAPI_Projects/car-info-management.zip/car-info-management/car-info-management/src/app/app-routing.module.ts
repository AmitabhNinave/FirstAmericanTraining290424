import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CarDetailsComponent } from './car-details/car-details.component';
import { CarTransmissionComponent } from './car-transmission/car-transmission.component';
import { CarTypeComponent } from './car-type/car-type.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {
    path:"car-details" , component:CarDetailsComponent
  },
  {
    path:"car-transmission-type" , component:CarTransmissionComponent
  },
  {
    path:"car-type" , component:CarTypeComponent
  },
  {
    path:"login" , component:LoginComponent
  },
  {
    path:"Register" , component:RegisterComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
