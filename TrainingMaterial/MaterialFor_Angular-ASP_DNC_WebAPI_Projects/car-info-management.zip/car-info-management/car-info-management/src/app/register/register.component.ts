import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { SharedService } from '../service/shared.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public registerform = this.formbuilder.group({
    UserName:['',Validators.required],
    Email:['',Validators.required],
    
    Password:['',Validators.required],
    Role:['',Validators.required]
  })

  constructor(private formbuilder:FormBuilder,private registerservice:SharedService) { }

  ngOnInit(): void {
  }

  onSubmit(){
    
    let UserName=this.registerform.controls["UserName"].value;
    let Email=this.registerform.controls["Email"].value;
    let Role=this.registerform.controls["Role"].value;
    let Password=this.registerform.controls["Password"].value;
    this.registerservice.register(UserName,Email,Role,Password).subscribe((data)=>{
      console.log(data);
    })
  }

}
