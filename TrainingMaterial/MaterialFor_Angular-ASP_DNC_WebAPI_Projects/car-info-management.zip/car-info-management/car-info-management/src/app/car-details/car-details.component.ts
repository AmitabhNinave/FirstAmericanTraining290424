import { CompileShallowModuleMetadata } from '@angular/compiler';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';

import { SharedService } from '../service/shared.service';
import { CarDetailsFormComponent } from './car-details-form/car-details-form.component';

@Component({
  selector: 'app-car-details',
  templateUrl: './car-details.component.html',
  styleUrls: ['./car-details.component.css']
})
export class CarDetailsComponent implements OnInit {
  columnDisplay = ['id', 'model','engine','bhp','mileage','seat','airbag','bootspace','price','manf','trans','type','action'];
  dataSource;

 

  @ViewChild(MatPaginator, { static: true } as any) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true } as any) sort: MatSort;
  constructor(
    private dialog: MatDialog,
   private _sharedService : SharedService
  ) { }

  ngOnInit(): void {
    this.getCarList();
  }

//get all car list
  getCarList(){
    this._sharedService.getCarList().subscribe(data=>{
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      //console.log(data);
      //window.localStorage.clear(); //clear all localstorage
      //window.localStorage.removeItem("TokenInfo"); //remove one item
    });
 
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  //pass data to form for edit operation
  editData(details){
    const dialogRef = this.dialog.open(CarDetailsFormComponent, {
      maxHeight: '90%',
      width: '70%',
      data: { details: details }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.getCarList();
    })
  }

  //delete specific details
  deleteData(dataItem:any){
    console.log(dataItem);
    if(confirm("Are you sure??")){
      this._sharedService.deleteCar(dataItem.id).subscribe(data=>{
        alert("Data deleted successfully");
        this.getCarList();
      })
    }
  }

}
