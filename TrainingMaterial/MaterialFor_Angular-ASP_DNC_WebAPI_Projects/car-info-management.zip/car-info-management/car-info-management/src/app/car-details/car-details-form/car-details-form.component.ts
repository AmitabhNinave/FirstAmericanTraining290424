import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SharedService } from 'src/app/service/shared.service';

@Component({
  selector: 'app-car-details-form',
  templateUrl: './car-details-form.component.html',
  styleUrls: ['./car-details-form.component.css']
})
export class CarDetailsFormComponent implements OnInit {
  formsource: FormGroup;
  formType = "add";
  CarTList = [];
  transmissionList = [];
  typeList=[];

  constructor(
    public dialogRef: MatDialogRef<CarDetailsFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private formbuilder: FormBuilder,
    private _sharedService: SharedService
  ) {
    this.formsource = this.formbuilder.group(
      {
        "id": [null],
        "modelName": ["", [Validators.required]],
        "manufId": ["", [Validators.required]],
        "cartype": ["", [Validators.required]],
        "Engine": ["", [Validators.required]],
        "bhp": ["", [Validators.required]],
        "trans": ["", [Validators.required]],
        "Mileage": ["", [Validators.required]],
        "BootSpace": ["", [Validators.required]],
        "Seat": ["", [Validators.required]],
        "airbag": ["", [Validators.required]],
        "Price": ["", [Validators.required]],
      });
  }

  ngOnInit(): void {
  //  this.loadCarTList();
  this.getTransList();
  this.getCarTypeList();
    if (this.data.details != undefined) {
      this.setDetails();
      this.formType = "update"
    }
  }

  getTransList(){
    this._sharedService.getCarTransmissionTypeList().subscribe((data:any)=>{
      this.transmissionList=data;
      console.log(this.transmissionList)
    });
  }

  getCarTypeList(){
    this._sharedService.getCarTypeList().subscribe((data:any)=>{
      this.typeList=data;
      console.log(this.typeList)
    })
  }

  get f() { return this.formsource.controls; }

  onNoClick() {
    this.dialogRef.close()
  }

  loadCarTList() {
    this._sharedService.getCarTransmissionTypeList().subscribe((data: any) => {
      this.CarTList = data;
      
    });
  }

  setDetails() {
    this.formsource.get("id").setValue(this.data.details.id);
      this.formsource.get("modelName").setValue(this.data.details.model);
      this.formsource.get("manufId").setValue(this.data.details.manufacturerId);
      this.formsource.get("cartype").setValue(this.data.details.typeId);
      this.formsource.get("Engine").setValue(this.data.details.engine);
      this.formsource.get("bhp").setValue(this.data.details.bhp);
      this.formsource.get("trans").setValue(this.data.details.transmissionId);
      this.formsource.get("Mileage").setValue(this.data.details.mileage);
      this.formsource.get("BootSpace").setValue(this.data.details.bootSpace);
      this.formsource.get("Seat").setValue(this.data.details.seat);
      this.formsource.get("airbag").setValue(this.data.details.airbagDetails);
      this.formsource.get("Price").setValue(this.data.details.price);
    console.log(this.data.details);
  }

  add() {
    var details = {
      "model": this.formsource.get("modelName").value,
      "manufacturerId":  this.formsource.get("manufId").value,
      "typeId":this.formsource.get("cartype").value,
      "engine": this.formsource.get("Engine").value,
      "bhp": this.formsource.get("bhp").value,
      "transmissionId": this.formsource.get("trans").value,
      "mileage": this.formsource.get("Mileage").value,
      "seat": this.formsource.get("Seat").value,
      "airbagDetails": this.formsource.get("airbag").value,
      "bootSpace": this.formsource.get("BootSpace").value,
      "price": this.formsource.get("Price").value,
    }

    this._sharedService.addCar(details).subscribe(res => {
      console.log(res);
      alert(res.toString());
    });
  }

  update() {
   
    var details = {
      "id": this.formsource.get("id").value,
      "model": this.formsource.get("modelName").value,
      "manufacturerId": this.formsource.get("manufId").value,
      "typeId": this.formsource.get("cartype").value,
      "engine": this.formsource.get("Engine").value,
      "transmissionId": this.formsource.get("trans").value,
      "mileage": this.formsource.get("Mileage").value,
      "bootSpace": this.formsource.get("BootSpace").value,
      "seat": this.formsource.get("Seat").value,
      "airBagDetails": this.formsource.get("airbag").value,
      "price": this.formsource.get("Price").value,
      "bhp": this.formsource.get("bhp").value
    };
    console.log(details);
    this._sharedService.updateCar(details).subscribe(res => {
      
      alert(res.toString());
    });
  }
}
