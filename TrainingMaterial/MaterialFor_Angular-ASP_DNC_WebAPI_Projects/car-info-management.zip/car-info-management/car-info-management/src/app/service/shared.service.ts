import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  private URL =  "https://localhost:44398/api";

  constructor(private http:HttpClient) { }

  getCarList():Observable<any>{
    return this.http.get<any>(this.URL+"/CarWebApi");
  }
  addCar(val:any){
    return this.http.post(this.URL+"/CarWebApi",val);
  }

  updateCar(val:any){
    const url = `${this.URL+"/CarWebApi/"+val.id}`;
      return this.http.put(url,val)
  }
  deleteCar(val:any){
    return this.http.delete(this.URL+"/CarWebApi/"+val);
  }

  getCarTransmissionTypeList():Observable<any[]>{
    return this.http.get<any>(this.URL+"/CarTransmissionTypeWebApi");
  }
  addCarTransmissionType(val:any){
    return this.http.post(this.URL+"/CarTransmissionTypeWebApi",val);
  }

  updateCarTransmissionType(val:any){
    const url = `${this.URL+"/CarTransmissionTypeWebApi/"+val.id}`;
    return this.http.put(url,val)
  }

  deleteCarTransmissionType(val:any){
    const url = `${this.URL+"/CarTransmissionTypeWebApi/"+val}`;
    return this.http.delete(url)
  }

  getCarTypeList():Observable<any[]>{
    return this.http.get<any>(this.URL+"/CarTypeWebApi");
  }
  addCarType(val:any){
    return this.http.post(this.URL+"/CarTypeWebApi/",val);
  }

  updateCarType(val:any){
    const url = `${this.URL+"/CarTypeWebApi/"+val.id}`;
    return this.http.put(url,val)
  }

  deleteCarType(val:any){
    const url = `${this.URL+"/CarTypeWebApi/"+val}`;
    return this.http.delete(url)
  }

  getAllCar():Observable<any[]>{
    return this.http.get<any[]>(this.URL+'/CarWebApi');
  }

  public login(UserName:string, Password:string){
    const body={
      userName:UserName,
      password:Password
    }
   return this.http.post(this.URL+'/Authenticate/login',body);
  }

  public register(UserName:string,Email:string,Role:String, Password:string){
    const body={
      userName:UserName,
      email:Email,
      role:Role,
      password:Password
    }
   return this.http.post(this.URL+'/Authenticate/registeradmin',body);
  }
}
