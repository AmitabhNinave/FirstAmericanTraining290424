import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { SharedService } from '../service/shared.service';

import { decode } from 'punycode';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public loginform = this.formbuilder.group({
    UserName:['',Validators.required],
    Password:['',Validators.required]
  })

  constructor(private formbuilder:FormBuilder,private loginservice:SharedService) { }

  ngOnInit(): void {
  }

  onSubmit(){
    
    let UserName=this.loginform.controls["UserName"].value;
    let Password=this.loginform.controls["Password"].value;
    this.loginservice.login(UserName,Password).subscribe((data)=>{
      console.log(data);
      localStorage.setItem('TokenInfo', JSON.stringify(data));
      let token = localStorage.getItem('TokenInfo');
      
    })
  }

}
