import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './material-module';
import { CarDetailsComponent } from './car-details/car-details.component';
import { CarTransmissionComponent } from './car-transmission/car-transmission.component';
import { CarTypeComponent } from './car-type/car-type.component';
import { CarDetailsFormComponent } from './car-details/car-details-form/car-details-form.component';
import { CarTypeFormComponent } from './car-type/car-type-form/car-type-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CarTransmissionFormComponent } from './car-transmission/car-transmission-form/car-transmission-form.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { httpInterceptor } from './Interceptor/Interceptor';
//import { ErrorInterceptor } from './Interceptor/errorInterceptor';

import { AuthorizationCheck } from './Service/authorizationCheck'
//import { AuthenticationService } from './Service/authentication.service'



@NgModule({
  declarations: [
    AppComponent,
    CarDetailsComponent,
    CarTransmissionComponent,
    CarTypeComponent,
    CarDetailsFormComponent,
    CarTypeFormComponent,
    CarTransmissionFormComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers:  [{ provide: HTTP_INTERCEPTORS, useClass: httpInterceptor, multi: true },
  AuthorizationCheck],
  bootstrap: [AppComponent]
})
export class AppModule { }
