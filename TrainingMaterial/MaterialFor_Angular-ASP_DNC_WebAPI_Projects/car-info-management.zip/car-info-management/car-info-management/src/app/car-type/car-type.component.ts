import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { SharedService } from '../service/shared.service';
import { CarTypeFormComponent } from './car-type-form/car-type-form.component';

const tableData = [
  {"id":1 , "type":"manual"}
]

@Component({
  selector: 'app-car-type',
  templateUrl: './car-type.component.html',
  styleUrls: ['./car-type.component.css']
})
export class CarTypeComponent implements OnInit {
  columnDisplay = ['id', 'title','action'];
  dataSource;

  @ViewChild(MatPaginator, { static: true } as any) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true } as any) sort: MatSort;
  constructor(
    private dialog: MatDialog,
   private _sharedService : SharedService
  ) { }

  ngOnInit(): void {
    this.getCarTypes();
  }

//get all car types list
  getCarTypes(){
    this._sharedService.getCarTypeList().subscribe(data=>{
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  //pass data to form for edit operation
  editData(details){
    const dialogRef = this.dialog.open(CarTypeFormComponent, {
      maxHeight: '90%',
      width: '70%',
      data: { details: details }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.getCarTypes();
    })
  }

  //delete specific details
  deleteData(dataItem:any){
    console.log(dataItem);
    if(confirm("Are you sure??")){
      this._sharedService.deleteCarType(dataItem.id).subscribe(data=>{
        alert("deleted successfully");
        this.getCarTypes();
      })
    }
  }
}
