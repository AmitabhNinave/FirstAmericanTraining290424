import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SharedService } from 'src/app/service/shared.service';

@Component({
  selector: 'app-car-type-form',
  templateUrl: './car-type-form.component.html',
  styleUrls: ['./car-type-form.component.css']
})
export class CarTypeFormComponent implements OnInit {
  formsource:FormGroup;
  formType="add";
  CarTList=[];

  constructor(
    public dialogRef: MatDialogRef<CarTypeFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private formbuilder:FormBuilder,
    private _sharedService : SharedService
  ) {
    this.formsource = this.formbuilder.group(
      {
        "id":[null],
        "cartype":["",[Validators.required]],
      });
   }

  ngOnInit(): void {
    this.loadCarTList();
    if(this.data.details!=undefined){
      this.setDetails();
      this.formType="update"
    }
  }

  get f() { return this.formsource.controls; }

  onNoClick() {
    this.dialogRef.close()
  }

  //get car transmission type list
  loadCarTList(){
    this._sharedService.getCarTransmissionTypeList().subscribe((data:any)=>{
      this.CarTList=data;
    }); 
  }

  //set cartransmission type
  setDetails(){
    
    this.formsource.get("cartype").setValue(this.data.details.type);
    this.formsource.get("id").setValue(this.data.details.id);

  }

  //add car trans type
  addType(){
    let val = {
      "type":this.formsource.get("cartype").value
    }
    this._sharedService.addCarType(val).subscribe(res=>{
      alert("Data Added Successfully ");
    });
    
  }

  //update car trans type
  updateType(){
    let val = {
      "id" : this.formsource.get("id").value,
      "type" : this.formsource.get("cartype").value
    }
    this._sharedService.updateCarType(val).subscribe(res=>{
      alert("Data Updated Successfully ");
});
  }

}
