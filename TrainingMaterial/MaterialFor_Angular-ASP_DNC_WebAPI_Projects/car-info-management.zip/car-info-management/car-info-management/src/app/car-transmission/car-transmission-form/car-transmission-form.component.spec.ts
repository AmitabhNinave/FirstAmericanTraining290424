import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarTransmissionFormComponent } from './car-transmission-form.component';

describe('CarTransmissionFormComponent', () => {
  let component: CarTransmissionFormComponent;
  let fixture: ComponentFixture<CarTransmissionFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarTransmissionFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarTransmissionFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
