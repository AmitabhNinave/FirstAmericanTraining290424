import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { SharedService } from '../service/shared.service';
import { CarTransmissionFormComponent } from './car-transmission-form/car-transmission-form.component';

@Component({
  selector: 'app-car-transmission',
  templateUrl: './car-transmission.component.html',
  styleUrls: ['./car-transmission.component.css']
})
export class CarTransmissionComponent implements OnInit {

  columnDisplay = ['id', 'title','action'];
  dataSource;

  @ViewChild(MatPaginator, { static: true } as any) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true } as any) sort: MatSort;
  constructor(
    private dialog: MatDialog,
   private _sharedService : SharedService
  ) { }

  ngOnInit(): void {
    this.getCarTransmissionTypeList();
  }

//get all car types list
getCarTransmissionTypeList(){
    this._sharedService.getCarTransmissionTypeList().subscribe(data=>{
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  editData(details){
    const dialogRef = this.dialog.open(CarTransmissionFormComponent, {
      maxHeight: '90%',
      width: '70%',
      data: { details: details }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.getCarTransmissionTypeList();
    })
  }

  //delete specific details
  deleteData(dataItem:any){
    console.log(dataItem);
    if(confirm("Are you sure??")){
      this._sharedService.deleteCarTransmissionType(dataItem.id).subscribe(data=>{
        alert("Deleted Successfully");
        this.getCarTransmissionTypeList();
      })
    }
  }

}
