import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SharedService } from 'src/app/service/shared.service';

@Component({
  selector: 'app-car-transmission-form',
  templateUrl: './car-transmission-form.component.html',
  styleUrls: ['./car-transmission-form.component.css']
})
export class CarTransmissionFormComponent implements OnInit {

  formsource:FormGroup;
  formType="add";
  CarTList=[];
  constructor(
    public dialogRef: MatDialogRef<CarTransmissionFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private formbuilder:FormBuilder,
    private _sharedService : SharedService
  ) {
    this.formsource = this.formbuilder.group(
      {
        "id":[null],
        "carname":["",[Validators.required]],
      });
   }

  ngOnInit(): void {
    this.loadCarTList();
    if(this.data.details!=undefined){
      this.setDetails();
      this.formType="update"
    }
  }
  get f() { return this.formsource.controls; }

  onNoClick() {
    this.dialogRef.close()
  }

  loadCarTList(){
    this._sharedService.getCarTransmissionTypeList().subscribe((data:any)=>{
      this.CarTList=data;
    }); 
  }

  setDetails(){
    
    this.formsource.get("carname").setValue(this.data.details.name);
    this.formsource.get("id").setValue(this.data.details.id);

  }

  addType(){
    let val = {
      "name":this.formsource.get("carname").value
    }
    this._sharedService.addCarTransmissionType(val).subscribe(res=>{
      console.log(res);
      alert("Data Added Successfully ");
    });
    
  }

  updateType(){
    let val = {
      "id" : this.formsource.get("id").value,
      "name" : this.formsource.get("carname").value
    }
    this._sharedService.updateCarTransmissionType(val).subscribe(res=>{
      alert("Data Updated Successfully ");
});
  }

}
